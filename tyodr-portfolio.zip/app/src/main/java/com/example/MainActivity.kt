package com.example

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDarkTheme by remember { mutableStateOf(true) }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        FooterBar(isDarkTheme)
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = { isDarkTheme = !isDarkTheme },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurface,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .padding(bottom = 16.dp, end = 8.dp)
                                .size(56.dp)
                                .shadow(
                                    elevation = 24.dp,
                                    shape = RoundedCornerShape(16.dp),
                                    ambientColor = MaterialTheme.colorScheme.onBackground,
                                    spotColor = MaterialTheme.colorScheme.onBackground
                                )
                        ) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.WbSunny else Icons.Default.Nightlight,
                                contentDescription = "Toggle Theme",
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .padding(innerPadding)
                            .fillMaxSize()
                            .padding(8.dp) // m-2
                    ) {
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(24.dp), // rounded-3xl
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline), // border-white/10
                            shadowElevation = 24.dp // shadow-2xl
                        ) {
                            PortfolioWebView(url = "https://tyodr.github.io/ListWeb/", isDarkTheme = isDarkTheme)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FooterBar(isDarkTheme: Boolean) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Transparent)
    ) {
        Text(
            text = "CREATED BY TYODR",
            modifier = Modifier
                .padding(vertical = 16.dp, horizontal = 24.dp)
                .fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Light,
            fontSize = 10.sp,
            letterSpacing = 2.sp, // tracking-[0.2em] approx
            color = if (isDarkTheme) Color(0x66FFFFFF) else Color(0x66000000)
        )
        
        // Home indicator style bar
        Box(
            modifier = Modifier
                .padding(bottom = 8.dp)
                .width(128.dp) // w-32
                .height(6.dp) // h-1.5
                .background(
                    if (isDarkTheme) Color(0x33FFFFFF) else Color(0x33000000), 
                    RoundedCornerShape(50)
                )
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PortfolioWebView(url: String, isDarkTheme: Boolean) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    
    // Convert MaterialTheme surface color to android.graphics.Color
    val androidColor = MaterialTheme.colorScheme.surface.toArgb()

    BackHandler(enabled = true) {
        if (webView?.canGoBack() == true) {
            webView?.goBack()
        }
    }

    AndroidView(
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                }
                
                setBackgroundColor(androidColor)
                
                loadUrl(url)
                webView = this
            }
        },
        update = {
            it.setBackgroundColor(androidColor)
            webView = it
        },
        modifier = Modifier.fillMaxSize()
    )
}

