package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElegantGreenAccent,
    secondary = ElegantGreenAccent,
    tertiary = ElegantGreenAccent,
    background = ElegantDarkBg,
    surface = Color(0xFF000000), // Map surface to the black container
    onPrimary = ElegantDarkBg,
    onSecondary = ElegantDarkBg,
    onTertiary = ElegantDarkBg,
    onBackground = ElegantTextPrimary,
    onSurface = ElegantTextPrimary,
    surfaceVariant = ElegantDarkSurfaceVariant,
    onSurfaceVariant = ElegantTextPrimary,
    outline = ElegantBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = ElegantGreenAccent,
    secondary = ElegantGreenAccent,
    tertiary = ElegantGreenAccent,
    background = Color(0xFFF3F4F6), // gray-100
    surface = Color(0xFFFFFFFF), // white container
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFE5E7EB), // gray-200
    onSurfaceVariant = Color.Black,
    outline = Color(0x1A000000) // black/10
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
