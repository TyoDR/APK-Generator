package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ElegantDarkBg = Color(0xFF050505)
val ElegantDarkSurface = Color(0xFF111111)
val ElegantDarkSurfaceVariant = Color(0xFF1A1A1A)
val ElegantGreenAccent = Color(0xFF4ADE80) // green-400
val ElegantTextPrimary = Color(0xFFE0E0E0)
val ElegantTextSecondary = Color(0x66FFFFFF) // white/40
val ElegantBorder = Color(0x1AFFFFFF) // white/10
