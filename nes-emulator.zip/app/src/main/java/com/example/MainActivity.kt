package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.border
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.rotate
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import android.content.res.Configuration
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

class WebAppInterface(private val mContext: Context) {
    @android.webkit.JavascriptInterface
    fun showToast(toast: String) {
        android.widget.Toast.makeText(mContext, toast, android.widget.Toast.LENGTH_LONG).show()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NesEmulatorApp()
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NesEmulatorApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var loadedRomName by remember { mutableStateOf<String?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                val fileName = getFileName(context, uri) ?: "Game"
                loadedRomName = fileName
                val base64 = loadUriAsBase64(context, uri)
                if (base64 != null) {
                    webViewRef?.evaluateJavascript("window.loadRomBase64('$base64');") { result ->
                        if (result != null && result.contains("Error")) {
                            android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            android.widget.Toast.makeText(context, "ROM Loaded successfully!", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    fun handleBtnDown(id: Int) {
        webViewRef?.evaluateJavascript("window.buttonDown($id);", null)
    }

    fun handleBtnUp(id: Int) {
        webViewRef?.evaluateJavascript("window.buttonUp($id);", null)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0xFFD0BCFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF381E72))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("RetroNES", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E1E5))
                            Text(loadedRomName ?: "NO ROM LOADED", fontSize = 10.sp, color = Color(0xFFCAC4D0), letterSpacing = 1.sp)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { filePickerLauncher.launch("application/octet-stream") }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Load ROM", tint = Color(0xFFE6E1E5))
                    }
                    IconButton(onClick = { /* No-op for styling */ }) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFFE6E1E5))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C1B1F),
                    titleContentColor = Color(0xFFE6E1E5),
                    actionIconContentColor = Color(0xFFE6E1E5)
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF1C1B1F))
        ) {
            val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

            if (isLandscape) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Controller Area (Left)
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .clip(RoundedCornerShape(topEnd = 32.dp))
                            .background(Color(0xFF25232A))
                            .shadow(24.dp)
                    ) {
                        ControllerLayout(onButtonDown = ::handleBtnDown, onButtonUp = ::handleBtnUp, landscape = true, leftAlign = true)
                    }

                    // Screen Area
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(2f)
                            .background(Color(0xFF1C1B1F)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(modifier = Modifier
                            .fillMaxHeight(0.9f)
                            .aspectRatio(4f/3f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF121212))
                            .border(1.dp, Color.White.copy(alpha=0.1f), RoundedCornerShape(8.dp))
                            .shadow(24.dp)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    WebView(ctx).apply {
                                        settings.javaScriptEnabled = true
                                        settings.domStorageEnabled = true
                                        settings.allowFileAccess = true
                                        settings.allowFileAccessFromFileURLs = true
                                        settings.allowUniversalAccessFromFileURLs = true
                                        settings.mediaPlaybackRequiresUserGesture = false
                                        webChromeClient = object : WebChromeClient() {
                                            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage): Boolean {
                                                android.util.Log.d("NES_JS", consoleMessage.message())
                                                return super.onConsoleMessage(consoleMessage)
                                            }
                                        }
                                        webViewClient = WebViewClient()
                                        addJavascriptInterface(WebAppInterface(context), "AndroidEnv")
                                        loadUrl("file:///android_asset/index.html")
                                        webViewRef = this
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        if (loadedRomName == null) {
                            Text(
                                text = "Load ROM via folder icon",
                                color = Color(0xFF444444),
                                modifier = Modifier.background(Color.Transparent).padding(16.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Controller Area (Right)
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .clip(RoundedCornerShape(topStart = 32.dp))
                            .background(Color(0xFF25232A))
                            .shadow(24.dp)
                    ) {
                         ControllerLayout(onButtonDown = ::handleBtnDown, onButtonUp = ::handleBtnUp, landscape = true, leftAlign = false)
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Screen Area
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color(0xFF1C1B1F))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(4f/3f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF121212))
                            .border(1.dp, Color.White.copy(alpha=0.1f), RoundedCornerShape(8.dp))
                            .shadow(24.dp)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    WebView(ctx).apply {
                                        settings.javaScriptEnabled = true
                                        settings.domStorageEnabled = true
                                        settings.allowFileAccess = true
                                        settings.allowFileAccessFromFileURLs = true
                                        settings.allowUniversalAccessFromFileURLs = true
                                        settings.mediaPlaybackRequiresUserGesture = false
                                        webChromeClient = object : WebChromeClient() {
                                            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage): Boolean {
                                                android.util.Log.d("NES_JS", consoleMessage.message())
                                                return super.onConsoleMessage(consoleMessage)
                                            }
                                        }
                                        webViewClient = WebViewClient()
                                        addJavascriptInterface(WebAppInterface(context), "AndroidEnv")
                                        loadUrl("file:///android_asset/index.html")
                                        webViewRef = this
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        if (loadedRomName == null) {
                            Text(
                                text = "Load ROM via folder icon",
                                color = Color(0xFF444444),
                                modifier = Modifier.background(Color.Transparent).padding(16.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Controller Area
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                            .background(Color(0xFF25232A))
                            .shadow(24.dp)
                    ) {
                        ControllerLayout(onButtonDown = ::handleBtnDown, onButtonUp = ::handleBtnUp, landscape = false)
                    }
                }
            }
        }
    }
}

fun Modifier.nesButton(onDown: () -> Unit, onUp: () -> Unit, haptic: HapticFeedback) = this.pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onDown()
        waitForUpOrCancellation()
        onUp()
    }
}

@Composable
fun ControllerLayout(
    onButtonDown: (Int) -> Unit,
    onButtonUp: (Int) -> Unit,
    landscape: Boolean = false,
    leftAlign: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (!landscape || leftAlign) {
            // D-Pad Configuration
            Box(
                modifier = Modifier
                    .align(if (landscape) Alignment.Center else Alignment.CenterStart)
                    .padding(if (landscape) 0.dp else 16.dp)
                    .size(140.dp)
                    .background(Color(0xFF1C1B1F), shape = CircleShape)
                    .border(4.dp, Color.White.copy(alpha = 0.05f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Visual Cross
                Box(modifier = Modifier.size(100.dp, 36.dp).background(Color(0xFF49454F), RoundedCornerShape(8.dp)))
                Box(modifier = Modifier.size(36.dp, 100.dp).background(Color(0xFF49454F), RoundedCornerShape(8.dp)))
                
                // Functional touch areas
                Box(modifier = Modifier.align(Alignment.TopCenter).size(36.dp, 48.dp).nesButton({ onButtonDown(4) }, { onButtonUp(4) }, haptic))
                Box(modifier = Modifier.align(Alignment.BottomCenter).size(36.dp, 48.dp).nesButton({ onButtonDown(5) }, { onButtonUp(5) }, haptic))
                Box(modifier = Modifier.align(Alignment.CenterStart).size(48.dp, 36.dp).nesButton({ onButtonDown(6) }, { onButtonUp(6) }, haptic))
                Box(modifier = Modifier.align(Alignment.CenterEnd).size(48.dp, 36.dp).nesButton({ onButtonDown(7) }, { onButtonUp(7) }, haptic))
            }
        }

        if (!landscape) {
            // Start/Select (Bottom Center)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val pillShape = RoundedCornerShape(percent = 50)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(56.dp, 20.dp)
                            .clip(pillShape)
                            .background(Color(0xFF49454F))
                            .nesButton({ onButtonDown(2) }, { onButtonUp(2) }, haptic)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("SELECT", color = Color(0xFFCAC4D0), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(56.dp, 20.dp)
                            .clip(pillShape)
                            .background(Color(0xFF49454F))
                            .nesButton({ onButtonDown(3) }, { onButtonUp(3) }, haptic)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("START", color = Color(0xFFCAC4D0), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        } else {
            // Landscape mode split Start/Select
            val pillShape = RoundedCornerShape(percent = 50)
            if (leftAlign) {
                Column(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp, 20.dp)
                            .clip(pillShape)
                            .background(Color(0xFF49454F))
                            .nesButton({ onButtonDown(2) }, { onButtonUp(2) }, haptic)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("SELECT", color = Color(0xFFCAC4D0), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            } else {
                Column(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp, 20.dp)
                            .clip(pillShape)
                            .background(Color(0xFF49454F))
                            .nesButton({ onButtonDown(3) }, { onButtonUp(3) }, haptic)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("START", color = Color(0xFFCAC4D0), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }

        if (!landscape || !leftAlign) {
            // A/B Buttons (Right)
            Box(
                modifier = Modifier
                    .align(if (landscape) Alignment.Center else Alignment.CenterEnd)
                    .padding(if (landscape) 0.dp else 16.dp)
                    .size(150.dp)
                    .rotate(-15f)
            ) {
                // Button B (Left-Bottomish)
                Column(
                    modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 20.dp, start = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .shadow(8.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Color(0xFFE8DEF8))
                            .nesButton({ onButtonDown(1) }, { onButtonUp(1) }, haptic),
                        contentAlignment = Alignment.Center
                    ) { 
                        Text("B", color = Color(0xFF1D192B), fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                }

                // Button A (Right-Topish)
                Column(
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .shadow(8.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Color(0xFFD0BCFF))
                            .nesButton({ onButtonDown(0) }, { onButtonUp(0) }, haptic),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("A", color = Color(0xFF381E72), fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

suspend fun loadUriAsBase64(context: Context, uri: Uri): String? {
    return withContext(Dispatchers.IO) {
        try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            inputStream?.use {
                val bytes = it.readBytes()
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

fun getFileName(context: Context, uri: Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result
}
